<?php
$mysql_host = "localhost"; // Localhost
$mysql_user = "root"; // Username
$mysql_pass = ""; // Password
$mysql_db = "trinityauth"; // Logon/Realmd/Auth DB
$core = "1"; // 2 = Arcemu || 1 = Mangos/Trinity
?>