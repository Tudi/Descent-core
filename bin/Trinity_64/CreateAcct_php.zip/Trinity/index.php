<?php include('function.php');?>
<!--DO NOT ALTER MY CODE-->
<head> 
<html>
<title>Server Name</title>


 <link href="./css/style.css" rel="stylesheet" type="text/css">
 </head> <body>
  <div class="wrapper">
 <?php if($_GET['do']=="register") { Register();}elseif($_GET['error']) { Error("".$_GET['error']."");}else{ ?>
 <p>&nbsp;</p>
 <center><form action='?do=register' method='POST'> <b>Username:</b><br>
 <div style="margin-left:auto; margin-right:auto;" align="center" id="login">
 <input name="user" type="text" value="Username" id="login" onFocus="this.value=''" /> </div>

 <br> <b>Password:</b><br>
 <div style=" margin-left:auto; margin-right:auto;" align="center" id="static-effect2" class="input-wrapper"> <input class="living-input" name="password" type="password" value="Password" onFocus="this.value=''" /> </div>

<table align="center" style="text-align:center; margin-top:5px;">
<span class="input">
<label for="sales"><b><br>Expansion:</b> </label><br>
<select style="color:ffffff; background-color: #2f2f2f;  -moz-border-radius: 5px; border-radius: 5px;" id="sales" name="flags">
<option value="32">Cataclysm</option>
<option value="24">Lich King</option>
</select>
</span>
<br /><br /> <input class="cpBtn" type="submit" value="Create Account" id="button"></td></tr></table>
</form>
</center>
 
 </div>
 
 <center><div class="footer"><p style="margin-top:200px;"><font color=white>Advertisement</font><a href="http://dispersion.info/"><font color="red"><br /><br /><b>Dispersion-WoW</b></center></font></p></div> <?php }?> </body> </html>
